package com.example.v_notepad.utilities

const val DATABASE_NAME="note_database"